# Editorial Design System

The shared visual language behind [wmjoons.com](https://wmjoons.com): semantic color tokens, Korean editorial typography, accessible content primitives, and a Markdown renderer for Next.js.

It is designed to keep a public reading experience and a local publishing console visually coherent without forcing product-specific UI into the same component set.

## What it demonstrates

- Semantic light/dark color tokens, including warm operations surfaces
- Clear title roles: display plus a complete document hierarchy from `h1` through `h6`
- Korean-first typography with Noto Sans KR and Noto Serif KR
- Markdown support for GFM tables, KaTeX, Mermaid, and literal single tildes
- Atomic Design taxonomy: foundations, atoms, molecules, organisms, and app patterns

## Local development

```bash
npm install
npm run build
npm run storybook
```

Storybook starts at [http://localhost:6006](http://localhost:6006). It is organized as `Foundations → Atoms → Molecules → Organisms → Patterns`, separating reusable components from app-bound interaction flows. Build its deployable static output with `npm run build-storybook`.

## Consumer setup

```tsx
import "@wmjoon/editorial-design-system/editorial.css";
import { EditorialMarkdown } from "@wmjoon/editorial-design-system";
```

```tsx
<EditorialMarkdown content={markdown} />
```

## Components

### Atoms

- `EditorialButton` and `EditorialIconButton`: labelled actions in `sm | md | lg`.
- `EditorialTag`: one topical taxonomy facet in `sm | md | lg`.
- `EditorialBadge`: one mutually exclusive status, type, or count in `sm | md | lg`.
- `EditorialInput`, `EditorialSelect`, `EditorialCheckbox`, and `EditorialTextArea`: labelled native form controls.

### Molecules

- `EditorialTags`: dot-separated topical metadata group, composed from `EditorialTag`.
- `EditorialSegmentedControl`: a compact fixed-option selection control.
- `EditorialNav`: brand, navigation links, and trailing actions.
- `EditorialSegmentedControl`: use this for `라이트 | 다크 | 시스템`; persistence belongs to each consuming application.
- `EditorialMetricStrip` and `EditorialContentCard`: operations metadata and content units.

### Organisms

- `EditorialMarkdown`: GFM, literal single tildes, tables, KaTeX, and Mermaid.
- `EditorialArticle`: page-title header and rendered body.
- `EditorialArticleHeader`: metadata, page title, subtitle, and tags.
- `EditorialCollection`: shared list/card content collection for feeds, archives, and topic pages.
- `EditorialKanbanBoard` and `EditorialEditorShell`: presentational operations organisms; the backoffice app owns its drag, save, and filesystem API behavior.

`EditorialMarkdown` standardizes typography, dark mode, and a 760px reading measure. The components are intentionally editorial primitives; product-specific dashboard UI remains in each consuming app.

### Composition contract

Visual similarity alone is not a component boundary. The shared organisms consume the same primitives that Storybook documents:

- A content type such as `essay` or `framework` is an `EditorialBadge`.
- A taxonomy such as `knowledge systems` or `reader path` is an `EditorialTag`; several facets render through `EditorialTags`.
- `EditorialContentCard` composes those atoms directly, rather than reproducing their borders or typography in local CSS.

This keeps a Storybook example, its DOM semantics, and the interface used by the backoffice aligned.

## Title roles

The hierarchy is semantic first, and the visual classes make the intent explicit.

- `editorial-display`: brand or landing-page display only. It is not a document-heading scale.
- `editorial-title-1`: a document/page `h1`.
- `editorial-title-2`: an `h2` section title.
- `editorial-title-3`: an `h3` subsection title.
- `editorial-title-4` through `editorial-title-6`: increasingly compact subsections and labels.

Markdown follows the same scale automatically: `#` through `######` render as `title-1` through `title-6`. `EditorialArticle` owns its page `h1`; therefore Markdown passed to it should normally start at `##`. The personal-site source adapter removes a leading `#` only when it exactly matches the frontmatter title, preventing duplicated article titles without altering standalone Markdown documents.

## Theme tokens

Every component uses the shared `--editorial-*` color tokens, so navigation, headers, tags, Markdown, tables, and diagrams follow the same light/dark palette. The system preference is used by default; set `data-editorial-theme="light"` or `data-editorial-theme="dark"` on `html` or a wrapping element to override it.

Use semantic tokens in consumer styles rather than literal hex values:

- Foreground: `--editorial-fg`, `--editorial-fg-muted`
- Surfaces: `--editorial-bg-canvas`, `--editorial-bg-surface`, `--editorial-bg-subtle`
- Structure: `--editorial-border`, `--editorial-overlay`
- Interaction: `--editorial-accent`, `--editorial-on-accent`, `--editorial-link`
- Editing and feedback: `--editorial-code-bg`, `--editorial-code-fg`, `--editorial-warning-bg`, `--editorial-warning-fg`
- Warm operations surfaces: `--editorial-canvas-warm`, `--editorial-surface-warm`, `--editorial-surface-strong`

## Releases

Create and push a `v*` tag after updating `package.json`. GitHub Actions publishes the scoped private package to GitHub Packages.

## Storybook deployment

The catalogue is intentionally independent from the reader and the backoffice. Create a Cloudflare Pages project from this repository with:

- Build command: `npm run build-storybook`
- Build output directory: `storybook-static`
- Production branch: `main`

No runtime secrets are required. A dedicated hostname such as `design.wmjoons.com` keeps the component reference separate from `wmjoons.com`.

## License

MIT. See [LICENSE](./LICENSE).
